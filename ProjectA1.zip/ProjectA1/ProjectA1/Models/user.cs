﻿using System;
namespace ProjectA1.Models
{
    public class user
    {
        public student()
        {
            public int userID { get; set; }
        [Required]

        public string Name { get; set; }
        [Required]

        public string institution { get; set; }
        [Required]

        public string Course { get; set; }
        [Required]

        public string Gender { get; set; }
        [Required]

        public string Email { get; set; }
        [Required]

        public DateTime DOB { get; set; }
}
    }
}
