﻿using System;
namespace ProjectA1.Models
{
    public class userDataAccess
    {
        string connections = "Data Source = ADMIN\\SQLEXPRESS; initial catalog = DB_usesData; trusted_connection=true";


        public userDataAccess()
        {
            //this will show user details
            public IEnumerable<user> GetAllUsers()
            {
                List<user> listUser = new List<user>();

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("GetAllUsers", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {
                        User user = new User();

                        user.userId = Convert.ToInt32(rdr["UserId"]);
                        user.Name = rdr["Name"].ToString();
                        user.institution = rdr["Institution"].ToString();
                        user.course = rdr["Course"].ToString();
                        user.Gender = rdr["Gender"].ToString();
                        user.Email = rdr["Email"].ToString();
                        user.DOB = Convert.ToDateTime(rdr["DOB"].ToString());
                        listUser.Add(user);
                    }
                    con.Close();
                }
                return listUser;


                //To change data of user

                public void ChangeUser(User user)
                {
                    using (SqlConnection con = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd = new SqlCommand("spUpdateEmployee", con);
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@UserId", user.Id);
                        cmd.Parameters.AddWithValue("@Name", user.Name);
                        cmd.Parameters.AddWithValue("@Gender", user.Gender);
                        cmd.Parameters.AddWithValue("@Institution", user.Institution);
                        cmd.Parameters.AddWithValue("@Course", user.COurse);
                        cmd.Parameters.AddWithValue("@DOB", user.DOB);
                        cmd.Parameters.AddWithValue("@Email", user.Email);
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }

                //this i will add user data     
                public void AddUser(User user
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("spAddEmployee", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Name", user.Name);
                    cmd.Parameters.AddWithValue("@Gender", user.Gender);
                    cmd.Parameters.AddWithValue("@Institution", user.Institution);
                    cmd.Parameters.AddWithValue("@Course", user.Course);
                    cmd.Parameters.AddWithValue("@DOB", user.DOB);
                    cmd.Parameters.AddWithValue("@Email", user.Email;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }

            //To Delete the record on a particular employee    
            public void DiscardUser(int? id)
            {

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("spDeleteEmployee", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@UserId", Id);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }
    }
}
