﻿using System;
namespace ProjectA1.Controllers
{
    public class userController
    {
        public userController : Controller
        {

            userDataAccess objuser = new ();

        public IActionResult Index()

        {
            List<User> listUser = new List<User>();
            listUser = objuser.GetAllUsers().ToList();

            return view(listUser);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return view();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind] User user)
        {
            if (ModelState.IsValid)
            {
                objuser.AddUser(user);
                return RedirectToAction("Index");

            }
            return View(user);
        }
        [HttpGet]
        public IActionResult Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            User user = objuser.GetUserData(id);

            if (user == null)
            {
                return NotFound();
            }
            return View(user);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind]User user)
        {
            if (id != User.Id)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                objuser.UpdateUser(user);
                return RedirectToAction("Index");
            }
            return View(user);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteCon(int? id)
        {
            objuser.DeleteUser(id);
            return RedirectToAction("Index");
        }
   
}

        }
    }
}
