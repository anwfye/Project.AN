﻿using System;
using System.Web;
using System.Web.UI;
namespace Application
{
    public partial class UserPage : System.Web.UI.MasterPage
    {
    }
}
